#include <reg51.h>
#include <string.h>
#define FULL_ROTATION_STEPS 150 // Full rotation for a 200-step motor
sbit rs = P1^0;
sbit rw = P1^1;
sbit en = P1^2;
sbit STEP1 = P1^4;     // Stepper motor control pin 1
sbit STEP2 = P1^5;     // Stepper motor control pin 2
sbit STEP3 = P1^6;     // Stepper motor control pin 3
sbit STEP4 = P1^7;     // Stepper motor control pin 4 int1


void delay(unsigned int ms) {
    unsigned int i, j;
    for (i = 0; i < ms; i++) {
        for (j = 0; j < 1275; j++); // Approximate delay
    }
}

void stepper_rotate_clockwise(unsigned int steps) {
    unsigned int i;
    for (i = 0; i < steps; i++) {
        STEP1 = 1; STEP2 = 0; STEP3 = 0; STEP4 = 0;
        delay(5);
       
        STEP1 = 0; STEP2 = 1; STEP3 = 0; STEP4 = 0;
        delay(5);
       
        STEP1 = 0; STEP2 = 0; STEP3 = 1; STEP4 = 0;
        delay(5);
       
        STEP1 = 0; STEP2 = 0; STEP3 = 0; STEP4 = 1;
        delay(5);
    }
}

// Function to rotate stepper motor counterclockwise
void stepper_rotate_counterclockwise(unsigned int steps) {
    unsigned int i;
    for (i = 0; i < steps; i++) {
        STEP1 = 0; STEP2 = 0; STEP3 = 0; STEP4 = 1;
        delay(5);
       
        STEP1 = 0; STEP2 = 0; STEP3 = 1; STEP4 = 0;
        delay(5);
       
        STEP1 = 0; STEP2 = 1; STEP3 = 0; STEP4 = 0;
        delay(5);
       
        STEP1 = 1; STEP2 = 0; STEP3 = 0; STEP4 = 0;
        delay(5);
    }
}











// Keypad connections
#define ROW P3 // Rows connected to P3^0 - P3^3
#define COL P3 // Columns connected to P3^4 - P3^6
int i;
void lcdcmd(unsigned char);
void lcddat(unsigned char);
void delay(unsigned int);
unsigned char read_keypad(void);

void main() {
    unsigned char input[20];
    unsigned char password[20] = "6789"; // Correct password
    unsigned int index = 0;
		unsigned int repeat=1;
		while(repeat==1){
    P2 = 0x00; // Initialize Port 2 for LCD
    P0 = 0x00; // Initialize Port 0 for LEDs
    ROW = 0xF0; // Set rows as input, columns as output

    // Prompt for password entry
    lcdcmd(0x38); // Initialize LCD in 8-bit mode
    delay(5);
    lcdcmd(0x01); // Clear display
    delay(10);
    lcdcmd(0x0C); // Display ON, Cursor OFF
    delay(5);
    lcdcmd(0x80); // Set cursor to first line
    delay(5);
    lcddat('E'); delay(5);
    lcddat('N'); delay(5);
    lcddat('T'); delay(5);
    lcddat('E'); delay(5);
    lcddat('R'); delay(5);
    lcddat(' '); delay(5);
    lcddat('P'); delay(5);
    lcddat('A'); delay(5);
    lcddat('S'); delay(5);
    lcddat('S'); delay(5);
		lcddat('W'); delay(5);
    lcddat('O'); delay(5);
    lcddat('R'); delay(5);
    lcddat('D'); delay(5);
		lcdcmd(0xC0);
    // Read password from keypad
    while (1) {
        unsigned char key = read_keypad();
        if (key != '\0') { // If a key is pressed
            if (key == '#') { // Enter key
                input[index] = '\0'; // Null-terminate the input
                break; // Exit input loop
            } else if (key == '*') { // Clear input
                index = 0;
                lcdcmd(0x01); // Clear display
                delay(10);
                continue;
            } else { // Add key to input
                input[index++] = key;
                lcddat(key); // Display key on LCD
                delay(5);
            }
        }
				delay(20);
    }
	index=0;
    // Check password
    if (strcmp(input, password) == 0) { // Correct password
        while (1) {
            // LCD Display: "UNLOCKED"
            lcdcmd(0x38);
            delay(5);
            lcdcmd(0x01);
            delay(10);
            lcdcmd(0x0C);
            delay(5);
            lcdcmd(0x80);
            delay(5);
						lcddat('D'); delay(5);
						lcddat('O'); delay(5);
						lcddat('O'); delay(5);
						lcddat('R'); delay(5);
						lcddat(' '); delay(5);
            lcddat('U'); delay(5);
            lcddat('N'); delay(5);
            lcddat('L'); delay(5);
            lcddat('O'); delay(5);
            lcddat('C'); delay(5);
            lcddat('K'); delay(5);
            lcddat('E'); delay(5);
            lcddat('D'); delay(5);

            // Light Chaser Effect
            for (i = 0; i < 8; i++) {
                P0 = (1 << i);
                delay(20);
            }
						stepper_rotate_clockwise(FULL_ROTATION_STEPS);
						stepper_rotate_counterclockwise(FULL_ROTATION_STEPS);
						delay(100);
						break;
						repeat=1;

        }
    }
		if (strcmp(input, password) != 0) { // Wrong password
        while (1) {
            // LCD Display: "ERROR"
            lcdcmd(0x38);
            delay(5);
            lcdcmd(0x01);
            delay(10);
            lcdcmd(0x0C);
            delay(5);
            lcdcmd(0x80);
            delay(5);
            lcddat('E'); delay(5);
            lcddat('R'); delay(5);
            lcddat('R'); delay(5);
            lcddat('O'); delay(5);
            lcddat('R'); delay(100);
						break;
        }
    }
		repeat=1;
	}
}

// Send command to LCD
void lcdcmd(unsigned char val) {
    P2 = val;
    rs = 0;
    rw = 0;
    en = 1;
    delay(2);
    en = 0;
}

// Send data to LCD
void lcddat(unsigned char val) {
    P2 = val;
    rs = 1;
    rw = 0;
    en = 1;
    delay(2);
    en = 0;
}

// Delay function


// Read keypad function
unsigned char read_keypad(void) {
    unsigned char row, col;
    unsigned char keys[4][3] = {
        {'1', '2', '3'},
        {'4', '5', '6'},
        {'7', '8', '9'},
        {'*', '0', '#'}
    };

    for (row = 0; row < 4; row++) {
        ROW = ~(1 << row); // Set one row low
        delay(2);
        col = (COL >> 4) & 0x07; // Read columns (3 bits: P3^4 to P3^6)
        if (col != 0x07) { // If a column is low
            if (!(col & 0x01)) return keys[row][0]; // Column 0
            if (!(col & 0x02)) return keys[row][1]; // Column 1
            if (!(col & 0x04)) return keys[row][2]; // Column 2
        }
    }
    return '\0'; // No key pressed
}
